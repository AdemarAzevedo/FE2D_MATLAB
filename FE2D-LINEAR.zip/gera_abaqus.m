function gera_abaqus( vet_nos,vet_elem,bound,forcax,forcay,vetabaqus)
% 
% FE2D_LINEAR is a simple program to solve plane stress and plane strain 
% problems in the academic purposes. The program generate an abaqus input
% file for comparison of results.
%
% You may only use this program for your own private purposes. If you 
% You can distribute this program if you reference us. 
% ( ADEMAR DE AZEVEDO CARDOSO - www.gacsolucoes.com )
% 
%  This program is provided without warranty of any kind, either
%  expressed or implied, including, but not limited to, any implied
%  warranties of fitness for purpose.
%  THIS PROGRAM IS NO GUARANTEED TO BE FREE FROM BUGS!!
%  This program will run entirely at your risk.
%  The results produced by this program are in no way guaranteed to be fit
%  for any purpose.
%  Under no circumstances will the authors/copyright holders be liable to
%  anyone for damages, including any general, special, incidental or
%  consequential damages arising from the use or inability to use the
%  program (including, but not limited to, loss or corruption of data,
%  failure of the program to operate in any particular way as well as
%  damages arising from the use of any results produced by the program
%  for any purpose).
% 
%  You may use this program if you fully understand and agree with
%  the terms of the above disclaimer. You are not allowed to use this program if you
%  do not agree with these conditions of use.
Em=vetabaqus(1);
nu=vetabaqus(2);
t=vetabaqus(3);
type=vetabaqus(4);
nx=vetabaqus(5);
ny=vetabaqus(6);
n_nos_total=size(vet_nos,1);
n_elem_total=size(vet_elem,1);
auxname1=int2str(nx);
auxname1=strcat(auxname1,'x');
auxname2=int2str(ny);
auxname2=strcat(auxname2,'_');
name='\abq_';
ext='.inp';
if type==1 %plane stress 
   auxname3='stress';
   name=strcat(name,auxname1,auxname2,auxname3,ext); 
else
   auxname3='strain';
   name=strcat(name,auxname1,auxname2,auxname3,ext);    
end;

%arq1=fopen([pwd '\abq_lin.inp '],'w');
arq1=fopen([pwd name],'w');
texto='**Heading \n ';
fprintf(arq1,texto );
texto='** Job name: Job-1 Model name: placa_flexao \n';
fprintf(arq1,texto);
texto='**Preprint, echo=NO, model=NO, history=NO, contact=NO \n';
fprintf(arq1,texto);
texto='*Node, NSET=ALLNODES \n';
fprintf(arq1,texto);
for i=1:n_nos_total
 fprintf(arq1,' %8.0f  , %8.5f  ,   %8.5f  ,   0.\n',vet_nos(i,1), vet_nos(i,2),vet_nos(i,3) );
end;
if type==1 %plane stress 
 texto='*ELEMENT, TYPE=CPS4    , ELSET=elems  \n';
else %plane strain 
 texto='*ELEMENT, TYPE=CPE4    , ELSET=elems  \n';    
end; 
fprintf(arq1,texto);
for i=1:n_elem_total
 fprintf(arq1,' %4.0f  , %4.0f  ,  %4.0f  ,  %4.0f  , %4.0f  \n',vet_elem(i,1), vet_elem(i,2),vet_elem(i,3) ,vet_elem(i,4),vet_elem(i,5));
end;
texto='*SOLID SECTION,  \n';
fprintf(arq1,texto);
texto=' ELSET=elems,   \n';
fprintf(arq1,texto);
texto='  MATERIAL=ACO   \n';
fprintf(arq1,texto);
fprintf(arq1,' %8.5e  , \n',t );
texto='*MATERIAL,NAME=ACO   \n';
fprintf(arq1,texto);
texto='*ELASTIC,TYPE=ISOTROPIC   \n';
fprintf(arq1,texto);
 fprintf(arq1,' %8.5e , %8.5e   \n', Em,nu);
texto='*DENSITY   \n';
fprintf(arq1,texto); 
 fprintf(arq1,' 7.82000E-09,  \n');
%fprintf(arq1,' %8.5e ,   \n', densidade);
 texto='*STEP   \n';
fprintf(arq1,texto); 
 texto='*STATIC    \n';
fprintf(arq1,texto); 
texto='*NSET,NSET=FIXACOES    \n';
fprintf(arq1,texto);  
for i=1:size(bound,1)
      if i<size(bound,1)
         fprintf(arq1,' %4.0f , ',bound(i) );  
	 else
       fprintf(arq1,' %4.0f ',bound(i) );         
	end; 
    if (rem(i,7)==0)
       fprintf(arq1,' \n ');  
   end;   
end;
 fprintf(arq1,' \n');   
if size(forcax,2) ~=0
	texto='*NSET,NSET=FORCASX    \n';
	fprintf(arq1,texto);  
	for i=1:size(forcax,2)
          if i<size(forcax,2)
           fprintf(arq1,' %4.0f , ',forcax(1,i) );  
		else
           fprintf(arq1,' %4.0f ',forcax(1,i) );  
		end; 
        if (rem(i,7)==0)
          fprintf(arq1,' \n ');  
       end;   
	end;
    fprintf(arq1,'  \n');       
end;  
if size(forcay,2) ~=0
	texto='*NSET,NSET=FORCASY    \n';
	fprintf(arq1,texto);  
	for i=1:size(forcay,2)
          if i<size(forcay,2)
           fprintf(arq1,' %4.0f , ',forcay(1,i) );  
		else
           fprintf(arq1,' %4.0f ',forcay(1,i) );  
		end;        
		if (rem(i,7)==0)
           fprintf(arq1,' \n ');  
		end;     
	end;
fprintf(arq1,'  \n');       
end;    
texto='*BOUNDARY,OP=NEW    \n';
fprintf(arq1,texto); 
% texto='  ALLNODES,    4,6,     0.00000E+00     \n';
% fprintf(arq1,texto); 
% texto='  ALLNODES,    3,,     0.00000E+00     \n';
% fprintf(arq1,texto); 
texto='   FIXACOES,    1,2,     0.00000E+00     \n';
fprintf(arq1,texto); 
if size(forcay,2) ~=0
  texto='*CLOAD,OP=NEW    \n';
  fprintf(arq1,texto); 
  for i=1:size(forcay,2)
    fprintf(arq1,' %4.0f ,   2,  %8.5e  \n',forcay(1,i), forcay(2,i)  );    
  end;
end;
if size(forcax,2) ~=0
  texto='*CLOAD,OP=NEW    \n';
  fprintf(arq1,texto); 
%  fprintf(arq1,'  FORCASY,    2,    %8.5e  \n',forcas(2,1);  
  	for i=1:size(forcax,2)
        fprintf(arq1,' %4.0f ,   1,  %8.5e  \n',forcax(1,i), forcax(2,i)  );  
	end;
end;
texto='*NODE FILE,FREQUENCY=1,GLOBAL=YES  \n';
fprintf(arq1,texto); 
texto='  U,  \n';
fprintf(arq1,texto); 
texto='*OUTPUT, FIELD, FREQUENCY=1 \n';
fprintf(arq1,texto); 
texto='*NODE OUTPUT, NSET=ALLNODES \n';
fprintf(arq1,texto); 
texto='  U,  \n';
fprintf(arq1,texto); 
texto='*ELEMENT OUTPUT, ELSET=elems  \n';
fprintf(arq1,texto); 
texto='  S,E  \n';
fprintf(arq1,texto); 
texto='*END STEP \n';
fprintf(arq1,texto); 
fclose('all');
