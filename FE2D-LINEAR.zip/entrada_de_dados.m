function [vet_nos,vet_elem,vet_dados,bound,forcax,forcay]=entrada_de_dados;
% 
% FE2D_LINEAR is a simple program to solve plane stress and plane strain 
% problems in the academic purposes. The program generate an abaqus input
% file for comparison of results.
%
% You may only use this program for your own private purposes. If you 
% You can distribute this program if you reference us. 
% ( ADEMAR DE AZEVEDO CARDOSO - www.gacsolucoes.com )
% 
%  This program is provided without warranty of any kind, either
%  expressed or implied, including, but not limited to, any implied
%  warranties of fitness for purpose.
%  THIS PROGRAM IS NO GUARANTEED TO BE FREE FROM BUGS!!
%  This program will run entirely at your risk.
%  The results produced by this program are in no way guaranteed to be fit
%  for any purpose.
%  Under no circumstances will the authors/copyright holders be liable to
%  anyone for damages, including any general, special, incidental or
%  consequential damages arising from the use or inability to use the
%  program (including, but not limited to, loss or corruption of data,
%  failure of the program to operate in any particular way as well as
%  damages arising from the use of any results produced by the program
%  for any purpose).
% 
%  You may use this program if you fully understand and agree with
%  the terms of the above disclaimer. You are not allowed to use this program if you
%  do not agree with these conditions of use.


clear all;
clc;
format long;

% 1 - para desenhar a viga e 2 - para rodar;
tipo_rodada=2; 

% 1 - plane stress e 2 - plane strain;
tipo_analise=1;  

%  beam length
L_viga=10;

%  beam height
H_viga=100;

%  num elements  in x axis
n_elem_x=10;

%  num elements in y axis
n_elem_y=10;

% modulo de elasticidade do material
%Em=2500000;
Em=2.1e5;
% coeficiente de Poisson
nu=3e-1;
% espessura do material
t=2;
if tipo_analise==2
     t=1;
end;     
%  total number of elements
n_elem_total=n_elem_x*n_elem_y;
% total number of nodes 
n_nos_total=(n_elem_y+1)*(n_elem_x+1);
% vetor com a incidencia dos elementos
vet_elem=ones(n_elem_total,5);
% matriz com os nos e suas coordenadas
vet_nos=ones(n_nos_total,3); % 3 por enquanto...
%fprintf(' vet_elem:  %5.0f\n ', length(vet_elem));
%fprintf(' vet_nos:  %5.0f\n ', length(vet_nos));
%  largura do elemento na direcao x
dx=L_viga / n_elem_x ;
%  largura do elemento na direcao y
dy=H_viga / n_elem_y;
%variaveis auxiliares cont2 e cont3 
cont2=1;
cont3=0;
% numera os nos de 1 a n_nos_total
for j=1:n_nos_total
    vet_nos(j,1)=j;
end;  
% numera os elementos de 1 a n_elem_total
for j=1:n_elem_total
    vet_elem(j,1)=j;
end;  
% define as coordenadas dos nos. veja numeracao na figura
for j=1:(n_elem_x+1)
    cont1=1;
    cont3=cont3+1;  
	for i=1:(n_elem_y+1)
      vet_nos(cont2,3)=(cont1-1)*dy;               %  coordenate y      
      vet_nos(cont2,2)=(cont3-1)*dx;               %  coordenate x
      cont1=cont1+1;
      cont2=cont2+1;    
    end;     
end
%boundary conditions 
%clamp the down side
bound = find(vet_nos(:,3)==0);
%clamp the upper side
%bound = find(vet_nos(:,3)==H_viga)
%clamp the left side
%bound = find(vet_nos(:,2)==0)
%clamp the right side
%bound = find(vet_nos(:,2)==L_viga)
%forca na direcao x. para fibra superior vet_nos(:,3)==H_viga;. para Lateral direita fazer vet_nos(:,2)==L_viga;
%para lateral esquerda fazer vet_nos(:,2)==0
forcax=[ ];
% auxx=find(vet_nos(:,2)==0);
% forcax=auxx';
% forcaX=100/size(auxx,1);
% for j=1:size(auxx,1)
%    forcax(2,j)=forcaX;
% end;  
%forca na direcao y na fibra superior. para Lateral direita fazer vet_nos(:,2)==L_viga;
%para lateral esquerda fazer vet_nos(:,2)==0
 auxy=find(vet_nos(:,3)==H_viga);
 forcay=auxy';
 %forcay eh a forca total. forcaY eh a forca por noh
 forcaY=5/size(auxy,1);
 for j=1:size(auxy,1)
    forcay(2,j)=forcaY;
 end;  
%forcay=[ ];
%k=2;
% define a incidencia dos elementos. da esquerda para a direita
ii=1;
v1=ii;                     % vertice 1
v2=ii*n_elem_y+2; % vertice 2
v3=v2+1;               % vertice 3
v4=v1+1;               % vertice 4
cont=1;
for i=1:n_elem_x
	for j=1:n_elem_y
        vet_elem(cont,2)=v1;
        vet_elem(cont,3)=v2;
        vet_elem(cont,4)=v3;
        vet_elem(cont,5)=v4;
        v1=v1+1;
		v2=v2+1;
		v3=v3+1;
		v4=v4+1;
        cont=cont+1;
	end;
    ii=ii+1;
    v1=v4;
    v2=ii*n_elem_y+ii+1; 
    v3=v2+1;
    v4=v1+1;
end;
%   if tipo_rodada==1
     mostra_malha(vet_nos,n_elem_y,n_elem_x);      
%      disp(' rode novamente para analise com tipo_rodada=2');
%      return; 
%   end;
%
vetabaqus(1)=Em;
vetabaqus(2)=nu;
vetabaqus(3)=t;
vetabaqus(4)=tipo_analise;
vetabaqus(5)=n_elem_x;
vetabaqus(6)=n_elem_y;
gera_abaqus( vet_nos,vet_elem,bound,forcax,forcay,vetabaqus);
% dimens�es da matriz de rigidez global: n_lin_K x n_col_K
vet_dados=[vetabaqus];