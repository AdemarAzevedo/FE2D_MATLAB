% 
% FE2D_LINEAR is a simple (and barely comment...) program to solve plane stress and plane strain 
% problems in the academic purposes. The program generate an abaqus
% input file (gera_abaqus.m) for comparison of results.
%
% You may only use this program for your own private purposes. If you 
% You can distribute this program if you reference us. 
% ( ADEMAR DE AZEVEDO CARDOSO - www.gacsolucoes.com )
% 
%  This program is provided without warranty of any kind, either
%  expressed or implied, including, but not limited to, any implied
%  warranties of fitness for purpose.
%  THIS PROGRAM IS NO GUARANTEED TO BE FREE FROM BUGS!!
%  This program will run entirely at your risk.
%  The results produced by this program are in no way guaranteed to be fit
%  for any purpose.
%  Under no circumstances will the authors/copyright holders be liable to
%  anyone for damages, including any general, special, incidental or
%  consequential damages arising from the use or inability to use the
%  program (including, but not limited to, loss or corruption of data,
%  failure of the program to operate in any particular way as well as
%  damages arising from the use of any results produced by the program
%  for any purpose).
% 
%  You may use this program if you fully understand and agree with
%  the terms of the above disclaimer. You are not allowed to use this program if you
%  do not agree with these conditions of use.
%
%
%
% change the number of elements in the routine 
% entrada_de_dados(lines 48 and 51).
%
[vet_nos,vet_elem,vet_dados,bound, forcax,forcay]=entrada_de_dados;
n_nos_total=size(vet_nos,1);
n_elem_total=size(vet_elem,1);
Em=vet_dados(1);
nu=vet_dados(2);
t=vet_dados(3);
tipo_analise=vet_dados(4);
n_gl=2;
n_lin_K=n_nos_total*n_gl;
n_col_K=n_lin_K;
% reset global stiffness matrix 
K=zeros(n_lin_K,n_col_K);
% assembly of  global stiffness matrix 
for i=1:n_elem_total
    kel=matriz_rigidez4(vet_nos(vet_elem(i,2),2),vet_nos(vet_elem(i,2),3),vet_nos(vet_elem(i,3),2),vet_nos(vet_elem(i,3),3),vet_nos(vet_elem(i,4),2),vet_nos(vet_elem(i,4),3),vet_nos(vet_elem(i,5),2),vet_nos(vet_elem(i,5),3),Em,nu,t,tipo_analise);
    v1=2*vet_elem(i,2);
    v2=2*vet_elem(i,3);
    v3=2*vet_elem(i,4);
    v4=2*vet_elem(i,5);   
% distribution of local element kel matrix into K.   
% line 1    
    K(v1-1,v1-1)     =  K(v1-1,v1-1) + kel(1,1); 
    K(v1-1,v1)        =  K(v1-1,v1)  + kel(1,2);           K(v1,v1-1)       =   K(v1-1,v1);
    K(v1-1,v2-1)     =  K(v1-1,v2-1) + kel(1,3);         K(v2-1,v1-1)    =   K(v1-1,v2-1) ;
    K(v1-1,v2)        =  K(v1-1,v2)  + kel(1,4);           K(v2,v1-1)       =   K(v1-1,v2) ;
    K(v1-1,v3-1)     =  K(v1-1,v3-1)  + kel(1,5);        K(v3-1,v1-1)    =   K(v1-1,v3-1) ;
    K(v1-1,v3)        =  K(v1-1,v3) + kel(1,6);            K(v3,v1-1)       =   K(v1-1,v3);
    K(v1-1,v4-1)     =  K(v1-1,v4-1)  + kel(1,7);        K(v4-1,v1-1)    =   K(v1-1,v4-1);
    K(v1-1,v4)        =  K(v1-1,v4) + kel(1,8);            K(v4,v1-1)       =   K(v1-1,v4) ;
%line 2
    K(v1,v1)        =  K(v1,v1)   +   kel(2,2); 
    K(v1,v2-1)     =  K(v1,v2-1)  + kel(2,3);              K(v2-1,v1)      =  K(v1,v2-1) ;
    K(v1,v2)        =  K(v1,v2) + kel(2,4);                  K(v2,v1)         =  K(v1,v2);
    K(v1,v3-1)     =  K(v1,v3-1)  + kel(2,5);              K(v3-1,v1)      =  K(v1,v3-1);      
    K(v1,v3)        =  K(v1,v3)  + kel(2,6);                 K(v3,v1)        =   K(v1,v3) ;
    K(v1,v4-1)     =  K(v1,v4-1) + kel(2,7);               K(v4-1,v1)     =   K(v1,v4-1);
    K(v1,v4)        =  K(v1,v4)  + kel(2,8);                 K(v4,v1)        =   K(v1,v4);
%line 3
    K(v2-1,v2-1)     = K(v2-1,v2-1)  + kel(3,3); 
    K(v2-1,v2)        =  K(v2-1,v2)  +  kel(3,4);          K(v2,v2-1)      =  K(v2-1,v2);
    K(v2-1,v3-1)     =   K(v2-1,v3-1)  + kel(3,5);       K(v3-1,v2-1)   =  K(v2-1,v3-1);
    K(v2-1,v3)        =   K(v2-1,v3)  + kel(3,6);          K(v3,v2-1)      =  K(v2-1,v3);
    K(v2-1,v4-1)     =   K(v2-1,v4-1)  + kel(3,7);       K(v4-1,v2-1)   =  K(v2-1,v4-1);      
    K(v2-1,v4)        =  K(v2-1,v4)  + kel(3,8);           K(v4,v2-1)      =  K(v2-1,v4);
%line 4
    K(v2,v2)        =   K(v2,v2) + kel(4,4); 
    K(v2,v3-1)     =  K(v2,v3-1) + kel(4,5);                K(v3-1,v2)     =  K(v2,v3-1) ;          
    K(v2,v3)        =  K(v2,v3)   + kel(4,6);                K(v3,v2)        =  K(v2,v3)  ;
    K(v2,v4-1)     =  K(v2,v4-1)  + kel(4,7);               K(v4-1,v2)     =  K(v2,v4-1) ;  
    K(v2,v4)        =   K(v2,v4)   + kel(4,8);                K(v4,v2)        =   K(v2,v4)  ;
%line 5
    K(v3-1,v3-1)  =  K(v3-1,v3-1)  + kel(5,5);               
    K(v3-1,v3)     =  K(v3-1,v3)   + kel(5,6);               K(v3,v3-1)     =  K(v3-1,v3)  ;    
    K(v3-1,v4-1)  =  K(v3-1,v4-1)  + kel(5,7);             K(v4-1,v3-1)  =  K(v3-1,v4-1);  
    K(v3-1,v4)     =  K(v3-1,v4)  + kel(5,8);                K(v4,v3-1)     =  K(v3-1,v4) ;    
%line 6
    K(v3,v3)       =  K(v3,v3)   + kel(6,6); 
    K(v3,v4-1)    =  K(v3,v4-1)  + kel(6,7);                     K(v4-1,v3)    =  K(v3,v4-1)  ;
    K(v3,v4)       =    K(v3,v4)  + kel(6,8);                      K(v4,v3)       =    K(v3,v4);
    
%line 7
    K(v4-1,v4-1)  =   K(v4-1,v4-1)  + kel(7,7);
    K(v4-1,v4)     = K(v4-1,v4)  +  kel(7,8);                        K(v4,v4-1)     = K(v4-1,v4) ;    
    
%line 8
    K(v4,v4)  = K(v4,v4)  +  kel(8,8);
end; 
K1=K;
% load vector (P)
P=zeros(n_lin_K,1);
if size(forcax,2) ~=0
  for i=1:size(forcax,2)
     P(2*forcax(1,i)-1)=forcax(2,i);
  end;
end;
if size(forcay,2) ~=0
  for i=1:size(forcay,2)
     P(2*forcay(1,i))=forcay(2,i);
  end;
end;
aux = size(bound,1);
for i = 1 : aux
	pos1  = 2*bound(i) - 1;
    pos2  = 2*bound(i) ;
	K(pos1 ,:) = 0;
	K(:, pos1 ) = 0;
	K(pos1, pos1) = 1;
	P(pos1) = 0;
	K(pos2 ,:) = 0;
	K(:, pos2 ) = 0;
	K(pos2, pos2) = 1;
	P(pos2) = 0;
end; % 
% solve linear system 
X=inv(K)*P;  
j=1;
%guarda o vetor de desloc. calculado X_ no vetor desloc. global X
%resolve for reactions 
Fext=P;
aux = size(bound,1);
for i = 1 : aux
	pos1  = 2*bound(i) - 1;
    pos2  = 2*bound(i) ;
    R(pos1)=K1(pos1,:)*X;
    R(pos2)=K1(pos2,:)*X;
    Fext(pos1)=R(pos1);
    Fext(pos2)=R(pos2);
end;   

% calcula o maior deslocamento
j=1;
maior=abs(X(1));
xmaior=2;
for i=1:n_lin_K
%   x5(j)=X(i);  %nao sei pra que serve!!!!!!!!!!!!1
  j=j+1;
  if abs(X(i))>maior
      maior=abs(X(i));
      xmaior=i;
  end;
end;
% guarda os deslocamentos na matriz vet_nos
j=1;
for i=1:n_nos_total
  vet_nos(i,4)=X(j);
  vet_nos(i,5)=X(j+1); 
  j=j+2;
end;
%stress calculation 
Fint=zeros(n_lin_K,1);
% matriz 3D para guardar as tensoes sxx,syy,sxy nos quatro nos para cada
% elemento
Selem=zeros(4,3,n_elem_total);
for i=1:n_elem_total
    vet_aux(1,:)=vet_nos(vet_elem(i,2),:);
    vet_aux(2,:)=vet_nos(vet_elem(i,3),:);
    vet_aux(3,:)=vet_nos(vet_elem(i,4),:);
    vet_aux(4,:)=vet_nos(vet_elem(i,5),:)  ;  
    [sigma_elem, fint_nos]=tensoes2(vet_aux,Em,nu,t,tipo_analise);
    v1=2*vet_elem(i,2);
    v2=2*vet_elem(i,3);
    v3=2*vet_elem(i,4);
    v4=2*vet_elem(i,5);  
    Fint(v1-1)=Fint(v1-1)+fint_nos(1);
    Fint(v1)=Fint(v1)+fint_nos(2);    
    Fint(v2-1)=Fint(v2-1)+fint_nos(3);
    Fint(v2)=Fint(v2)+fint_nos(4);    
    Fint(v3-1)=Fint(v3-1)+fint_nos(5);
    Fint(v3)=Fint(v3)+fint_nos(6);    
    Fint(v4-1)=Fint(v4-1)+fint_nos(7);
    Fint(v4)=Fint(v4)+fint_nos(8); 
    Selem(:,:,i)=sigma_elem;
end; 
%
%
% youa are encouraged to improve the routines mostra_malha and mostra_malha2
%  mostra_malha2(vet_nos,vet_elem,Selem);
%
% equilibrium check.
soma=Fint+Fext;
fprintf(' max. displacement = %10.8f  na position %10.0f  \n',maior,xmaior);
for i=1:n_nos_total
   fprintf('  %5.0f   %15.10f    %15.10f  \n',vet_nos(i,1),vet_nos(i,4),vet_nos(i,5));
end;  
disp('  linear');
