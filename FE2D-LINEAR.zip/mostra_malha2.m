function mostra_malha2(vet_nos,vet_elem,Selem);
% 
% FE2D_LINEAR is a simple program to solve plane stress and plane strain 
% problems in the academic purposes. The program generate an abaqus input
% file for comparison of results.
%
% You may only use this program for your own private purposes. If you 
% You can distribute this program if you reference us. 
% ( ADEMAR DE AZEVEDO CARDOSO - www.gacsolucoes.com )
% 
%  This program is provided without warranty of any kind, either
%  expressed or implied, including, but not limited to, any implied
%  warranties of fitness for purpose.
%  THIS PROGRAM IS NO GUARANTEED TO BE FREE FROM BUGS!!
%  This program will run entirely at your risk.
%  The results produced by this program are in no way guaranteed to be fit
%  for any purpose.
%  Under no circumstances will the authors/copyright holders be liable to
%  anyone for damages, including any general, special, incidental or
%  consequential damages arising from the use or inability to use the
%  program (including, but not limited to, loss or corruption of data,
%  failure of the program to operate in any particular way as well as
%  damages arising from the use of any results produced by the program
%  for any purpose).
% 
%  You may use this program if you fully understand and agree with
%  the terms of the above disclaimer. You are not allowed to use this program if you
%  do not agree with these conditions of use.
%
% mostra a malha para o usuario checar onde serao colocados as cargas e
% as restricoes.
%
figure(2);
% clf
pe =vet_elem(1:size(vet_elem,1),2:size(vet_elem,2));
v_nos=vet_nos(1:size(vet_nos,1),2:3);
px =v_nos(pe');
py =v_nos(pe'+size(v_nos,1));
for i=1:size(Selem,3)
    aux=0;
    for j=1:4
       aux=aux+Selem(j,1,i);        
    end;
    sxx(i)=aux/4;
end;    
zzz=[1; 1; 1; 1]*sxx;
%load px1;
patch(px, py, zzz);
title ('Sigma_x_x')
colorbar
axis off

figure(3);
% clf
pe =vet_elem(1:size(vet_elem,1),2:size(vet_elem,2));
v_nos=vet_nos(1:size(vet_nos,1),2:3);
px =v_nos(pe');
py =v_nos(pe'+size(v_nos,1));
for i=1:size(Selem,3)
    aux=0;
    for j=1:4
       aux=aux+Selem(j,2,i);        
    end;
    syy(i)=aux/4;
end;    
zzz=[1; 1; 1; 1]*syy;
%load px1;
patch(px, py, zzz);
title ('Sigma_y_y')
colorbar
axis off
% 
% % gc = matriz com a posicao dos n�s.
% % cm=connective matrix.
% figure(3)
% %Plotting
% gc=v_nos;
% cm=pe;
% verts=gc;
% faces=cm;
% gc_f=vet_nos(1:size(vet_nos,1),4:5);
% patch('Faces',faces,'Vertices',verts,'FaceColor',[.7 .7 .7]);
% alpha(0.1)
% %Plotting Deformed
% verts_def=gc+200*(gc_f-gc);%200 � o "scale".
% faces=cm;
% patch('Faces',faces,'Vertices',verts_def,'FaceColor','none','LineStyle','--');

