function [kel]=matriz_rigidez4(x1,y1,x2,y2,x3,y3,x4,y4,E,po,t,tipo)
% 
% FE2D_LINEAR is a simple program to solve plane stress and plane strain 
% problems in the academic purposes. The program generate an abaqus input
% file for comparison of results.
%
% You may only use this program for your own private purposes. If you 
% You can distribute this program if you reference us. 
% ( ADEMAR DE AZEVEDO CARDOSO - www.gacsolucoes.com )
% 
%  This program is provided without warranty of any kind, either
%  expressed or implied, including, but not limited to, any implied
%  warranties of fitness for purpose.
%  THIS PROGRAM IS NO GUARANTEED TO BE FREE FROM BUGS!!
%  This program will run entirely at your risk.
%  The results produced by this program are in no way guaranteed to be fit
%  for any purpose.
%  Under no circumstances will the authors/copyright holders be liable to
%  anyone for damages, including any general, special, incidental or
%  consequential damages arising from the use or inability to use the
%  program (including, but not limited to, loss or corruption of data,
%  failure of the program to operate in any particular way as well as
%  damages arising from the use of any results produced by the program
%  for any purpose).
% 
%  You may use this program if you fully understand and agree with
%  the terms of the above disclaimer. You are not allowed to use this program if you
%  do not agree with these conditions of use.
% calcula a matriz de rigidez para elemento retangular de 4 nos.
% xi,yi, para i=1..4 sao as coordenadas nodais, comecando da esquerda
% inferior e rodando no sentido anti-horario
%E=30*500; 
xi=[x1 x2 x3 x4];
yi=[y1 y2 y3 y4];
%chama funcao gauss que devolve os pesos e os locais de integracao
[pesos locais]=gauss(4);
% matriz local do elemento. sequencia das transparencias...
kel=zeros(8,8);
if tipo==2   % matriz de elasticidade plane strain
  auxD=E/((1+po)*(1-2*po));
  D=auxD*[(1-po) po 0; po  (1-po) 0; 0 0 ((1-2*po)/2)];
else
 % matriz de elasticidade plane stress
 auxD=E/(1-po*po);
 D=auxD*[1 po 0; po  1  0; 0 0 ((1-po)/2)];
end;
for i=1:size(pesos,1)
 aux=locais(i,:);
 r=aux(1);
 s=aux(2);
 Forma=0.25*[ (1-r)*(1-s)  (1+r)*(1-s)  (1+r)*(1+s)  (1-r)*(1+s)];
 Deriv_Natural=0.25*[ -(1-s)  (1-s)  (1+s)   -(1+s);  -(1-r)   -(1+r)   (1+r)    (1-r)];   
 J11=Deriv_Natural(1,:)*xi';
 J12=Deriv_Natural(1,:)*yi';
 J21=Deriv_Natural(2,:)*xi';
 J22=Deriv_Natural(2,:)*yi';
 J=[J11 J12;J21 J22];
 %R=inv(J);
 JAC=J11*J22-J21*J12;
 gama=(1/JAC)*[J22 -J12;-J21 J11];
 %gama=R;
 T=[1 0 0 0; 0 0 0 1; 0 1 1 0];
 ZEROS=[0 0; 0 0];
 GAMA=[gama ZEROS;ZEROS gama];
 N_linha(1,:)=[Deriv_Natural(1,1)   0  Deriv_Natural(1,2)  0  Deriv_Natural(1,3)  0  Deriv_Natural(1,4)  0];
 N_linha(2,:)=[Deriv_Natural(2,1)   0  Deriv_Natural(2,2)  0  Deriv_Natural(2,3)  0  Deriv_Natural(2,4)  0];
 N_linha(3,:)=[  0  Deriv_Natural(1,1)   0  Deriv_Natural(1,2)  0  Deriv_Natural(1,3)  0  Deriv_Natural(1,4)];
 N_linha(4,:)=[  0  Deriv_Natural(2,1)   0  Deriv_Natural(2,2)  0  Deriv_Natural(2,3)  0  Deriv_Natural(2,4)];
 B=T*GAMA*N_linha;
% save d:\impacto\Bkij.mat B;

% matriz de elasticidade plane strain 
 kel=kel+(t*JAC)*B'*D*B;
end;
%save  save E:\impacto\neuber\Bkij.mat kel;


 
 