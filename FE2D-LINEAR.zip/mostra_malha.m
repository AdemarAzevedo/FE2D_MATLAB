function mostra_malha(vet_nos,n_elem_y,n_elem_x);
% 
% FE2D_LINEAR is a simple program to solve plane stress and plane strain 
% problems in the academic purposes. The program generate an abaqus input
% file for comparison of results.
%
% You may only use this program for your own private purposes. If you 
% You can distribute this program if you reference us. 
% ( ADEMAR DE AZEVEDO CARDOSO - www.gacsolucoes.com )
% 
%  This program is provided without warranty of any kind, either
%  expressed or implied, including, but not limited to, any implied
%  warranties of fitness for purpose.
%  THIS PROGRAM IS NO GUARANTEED TO BE FREE FROM BUGS!!
%  This program will run entirely at your risk.
%  The results produced by this program are in no way guaranteed to be fit
%  for any purpose.
%  Under no circumstances will the authors/copyright holders be liable to
%  anyone for damages, including any general, special, incidental or
%  consequential damages arising from the use or inability to use the
%  program (including, but not limited to, loss or corruption of data,
%  failure of the program to operate in any particular way as well as
%  damages arising from the use of any results produced by the program
%  for any purpose).
% 
%  You may use this program if you fully understand and agree with
%  the terms of the above disclaimer. You are not allowed to use this program if you
%  do not agree with these conditions of use.
%
% mostra a malha para o usuario checar onde serao colocados as cargas e
% as restricoes.
%
figure(1);
kx=1;
ky=1;
x = kx*vet_nos(:,2);
y = ky*vet_nos(:,3);
z=ones((n_elem_y+1),(n_elem_x+1));
az = 0;
el = 90;
hold on;
surf(z);
alpha(0.1)
axis off;
view(az, el);
for i=1:n_elem_x+1
    for j=1:n_elem_y+1    
         text(i,j,num2str(vet_nos( (i-1)*(n_elem_y+1)+j,1)));  
   end;
end;
hold off;
%
%final da parte grafica